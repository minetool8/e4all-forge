package link.e4all.mixin;

import link.e4all.voice.VoiceControlPayload;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.common.ServerboundCustomPayloadPacket;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// same capture as the clientbound side, but the player context only exists at
// handleCustomPayload time, so stash for the listener mixin (same netty thread)
@Mixin(ServerboundCustomPayloadPacket.class)
public class ServerboundCustomPayloadPacketMixin {

    // vanilla caps unknown-channel payloads at 32767 here but accepts 1MB clientbound.
    // registered types are unaffected, this just keeps the sniffing fallback alive.
    @ModifyConstant(method = "lambda$static$0", constant = @Constant(intValue = 32767), require = 0, remap = false)
    private static int e4all$raiseFallbackPayloadLimit(int limit) {
        return 1048576;
    }

    @Inject(method = "readPayload",
            at = @At("HEAD"), require = 0)
    private static void e4all$captureVoicePayload(@Coerce Object id, FriendlyByteBuf buf,
                                                  CallbackInfoReturnable<CustomPacketPayload> cir) {
        try {
            if (!VoiceControlPayload.isOwnChannel(id)) return;
            byte[] data = VoiceControlPayload.readRemaining(new FriendlyByteBuf(buf.slice()));
            VoiceControlPayload.PENDING.set(data);
            VoiceControlPayload.enqueuePendingServer(data);
        } catch (Throwable t) {
            if (!e4all$captureWarned) {
                e4all$captureWarned = true;
                link.e4all.E4allClient.LOGGER.warn("e4all voice: serverbound voice payload capture failed (further failures stay silent)", t);
            }
        }
    }

    @Unique
    private static volatile boolean e4all$captureWarned = false;
}
