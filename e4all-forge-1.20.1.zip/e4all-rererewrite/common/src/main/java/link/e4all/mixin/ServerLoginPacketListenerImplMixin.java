package link.e4all.mixin;

import link.e4all.DialtoneConnectionExtensions;
import link.e4all.dialtone.DialtoneAddress;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.login.ServerboundKeyPacket;
import net.minecraft.server.network.ServerLoginPacketListenerImpl;
import net.minecraft.util.Crypt;
import net.minecraft.util.CryptException;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Arrays;
import org.spongepowered.asm.mixin.Unique;

@Mixin(ServerLoginPacketListenerImpl.class)
public class ServerLoginPacketListenerImplMixin {
    @Shadow @Final
    Connection connection;

    @Redirect(method = "handleHello", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/MinecraftServer;usesAuthentication()Z"), require = 0)
    private boolean e4all$redirectUsesAuthentication(net.minecraft.server.MinecraftServer instance) {
        if (link.e4all.Config.INSTANCE.offlineMode.value()) {
            return false;
        }
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return true;
        }
        return instance.usesAuthentication();
    }


    @ModifyArg(method = "handleHello", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/protocol/login/ClientboundHelloPacket;<init>(Ljava/lang/String;[B[BZ)V"), index = 3, require = 0)
    private boolean e4all$modifyNeedsAuthentication(boolean needsAuth) {
        if (link.e4all.Config.INSTANCE.offlineMode.value()) {
            return false;
        }
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return true;
        }
        return needsAuth;
    }

    @Redirect(method = "handleHello", at = @At(value = "INVOKE", target = "Ljava/security/PublicKey;getEncoded()[B"), require = 0)
    private byte[] killDoubleEncryption(PublicKey instance) {
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return new byte[0];
        }
        return instance.getEncoded();
    }

    @Redirect(method = "handleKey", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/protocol/login/ServerboundKeyPacket;isChallengeValid([BLjava/security/PrivateKey;)Z"), require = 0)
    private boolean isChallengeValid(ServerboundKeyPacket instance, byte[] bs, PrivateKey privateKey) {
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return true;
        }
        return instance.isChallengeValid(bs, privateKey);
    }

    @Redirect(method = "handleKey", at = @At(value = "INVOKE", target = "Ljava/util/Arrays;equals([B[B)Z"), require = 0)
    private boolean isNonceEqual(byte[] lhs, byte[] rhs) {
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return true;
        }
        return Arrays.equals(lhs, rhs);
    }

    @Redirect(method = "handleKey", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/protocol/login/ServerboundKeyPacket;getSecretKey(Ljava/security/PrivateKey;)Ljavax/crypto/SecretKey;"), require = 0)
    private SecretKey getSecretKey(ServerboundKeyPacket instance, PrivateKey privateKey) throws CryptException {
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return null;
        }
        return instance.getSecretKey(privateKey);
    }

    @WrapOperation(method = "handleKey", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Crypt;getCipher(ILjava/security/Key;)Ljavax/crypto/Cipher;"), require = 0)
    private Cipher getCipher(int i, Key key, Operation<Cipher> original) throws CryptException {
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return null;
        }
        return original.call(i, key);
    }

    @WrapOperation(method = "handleKey", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/Connection;setEncryptionKey(Ljavax/crypto/Cipher;Ljavax/crypto/Cipher;)V"), require = 0)
    private void e4all$setEncryptionKey(Connection instance, Cipher decrypt, Cipher encrypt, Operation<Void> original) {
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return;
        }
        if (decrypt != null && encrypt != null) {
            original.call(instance, decrypt, encrypt);
        }
    }

    @Redirect(method = "handleKey", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Crypt;digestData(Ljava/lang/String;Ljava/security/PublicKey;Ljavax/crypto/SecretKey;)[B"), require = 0)
    private byte[] digestData(String string, PublicKey publicKey, SecretKey secretKey) throws CryptException {
        if (connection.getRemoteAddress() instanceof DialtoneAddress) {
            return ((DialtoneConnectionExtensions) connection).e4mc$exportKeyingMaterial("EXPERIMENTAL mojang authentication".getBytes(StandardCharsets.UTF_8), new byte[0], 20);
        }
        return Crypt.digestData(string, publicKey, secretKey);
    }
}

