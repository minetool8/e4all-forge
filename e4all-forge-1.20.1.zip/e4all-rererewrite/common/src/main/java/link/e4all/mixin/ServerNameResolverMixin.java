package link.e4all.mixin;

import link.e4all.Config;
import link.e4all.E4allClient;
import link.e4all.SmugglersInetSocketAddress;
import link.e4all.TicketSmuggler;
import link.e4all.voice.VoiceBridge;
import net.minecraft.client.multiplayer.resolver.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Hashtable;
import java.util.Optional;

@Mixin(ServerNameResolver.class)
public class ServerNameResolverMixin {
    @Unique
    private static final HttpClient E4ALL_HTTP_CLIENT = HttpClient.newHttpClient();
    @ModifyArg(method = "<clinit>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/resolver/ServerNameResolver;<init>(Lnet/minecraft/client/multiplayer/resolver/ServerAddressResolver;Lnet/minecraft/client/multiplayer/resolver/ServerRedirectHandler;Lnet/minecraft/client/multiplayer/resolver/AddressCheck;)V"), index = 1, require = 0)
    private static ServerRedirectHandler addDialtoneRedirectHandler(ServerRedirectHandler innerHandler) {
        DirContext dirContext;
        try {
            Class.forName("com.sun.jndi.dns.DnsContextFactory");
            Hashtable<String, String> environment = new Hashtable<>();
            environment.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
            environment.put("java.naming.provider.url", "dns:");
            environment.put("com.sun.jndi.dns.timeout.retries", "1");
            environment.put("com.sun.jndi.dns.timeout.initial", "2000");
            dirContext = new InitialDirContext(environment);
            return serverAddress -> {
                var inner = innerHandler.lookupRedirect(serverAddress);
                // On Android we can only do Dialtone when a Bionic iroh native is
                // bundled; plain relay play is unaffected either way.
                if (!Config.INSTANCE.dialtonePlayerEnabled.value()
                        || (link.e4all.AndroidDetector.isAndroid() && !link.e4all.AndroidNatives.hasIrohNative())) {
                    return inner;
                } if (inner.isPresent()) {
                    return inner;
                } else if (serverAddress.getPort() == 25565) {
                    // skip dns txt lookup for raw ips since they wont have txt records
                    String host = serverAddress.getHost();
                    if (host != null && (host.matches("^\\d{1,3}(\\.\\d{1,3}){3}$") || host.startsWith("[") || host.contains(":"))) {
                        return Optional.empty();
                    }
                    try {
                        Attributes attributes = dirContext.getAttributes(serverAddress.getHost(), new String[]{"TXT"});
                        Attribute attribute = attributes.get("TXT");
                        if (attribute != null) {
                            var attrs = attribute.getAll();
                            while (attrs.hasMore()) {
                                var attr = attrs.next();
                                if (attr instanceof String str && str.startsWith("e4mc-dialtone-resolver=")) {
                                    var resolverAddr = str.substring(23);
                                    if (!serverAddress.getHost().endsWith(resolverAddr)) {
                                        E4allClient.LOGGER.warn("Ignoring resolver addr {} as it's not a suffix of the target address", resolverAddr);
                                        continue;
                                    }
                                    // cached, asking again on every server list ping just earns rate limited 404s
                                    link.e4all.DialtoneTicketCache.Lookup cached = link.e4all.DialtoneTicketCache.fresh(host);
                                    if (cached != null) {
                                        if (cached.hasTicket()) {
                                            e4all$smuggleTicket(serverAddress, cached.ticket);
                                            return Optional.of(serverAddress);
                                        }
                                        return Optional.empty();
                                    }
                                    var request = HttpRequest
                                            .newBuilder(new URI("https", resolverAddr, "/.well-known/dialtone_ticket/" + host, null))
                                            .timeout(Duration.ofSeconds(5))
                                            .build();
                                    E4allClient.LOGGER.debug("req: {}", request);
                                    var response = E4ALL_HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                                    E4allClient.LOGGER.debug("resp: {}", response);
                                    if (response.statusCode() == 200 && response.body().startsWith("v1_")) {
                                        String ticket = response.body().substring(3);
                                        link.e4all.DialtoneTicketCache.putTicket(host, ticket);
                                        e4all$smuggleTicket(serverAddress, ticket);
                                        return Optional.of(serverAddress);
                                    } else if (response.statusCode() == 404) {
                                        // 404 just means the host has no dialtone endpoint (e.g. android), the link is not expired
                                        link.e4all.DialtoneTicketCache.putNoTicket(host);
                                        E4allClient.LOGGER.debug("e4all: no Dialtone ticket for '{}' (HTTP 404), using the relay", host);
                                    } else {
                                        E4allClient.LOGGER.warn("e4all: Unexpected ticket response for '{}': HTTP {} (expected 200 or 404)", host, response.statusCode());
                                    }
                                }
                            }
                        }
                    } catch (Throwable e) {
                        E4allClient.LOGGER.warn("Could not check '{}' for a direct connection ticket", serverAddress.getHost(), e);
                    }
                }
                return Optional.empty();
            };
        } catch (Throwable e) {
            E4allClient.LOGGER.warn("Failed to create a Dialtone redirect handler", e);
        }
        return innerHandler;
    }

    @Redirect(method = "resolveAddress", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/resolver/ServerAddressResolver;resolve(Lnet/minecraft/client/multiplayer/resolver/ServerAddress;)Ljava/util/Optional;"), require = 0)
    private Optional<ResolvedServerAddress> resolveBogus(ServerAddressResolver instance, ServerAddress serverAddress) {
        var smuggledTicket = ((TicketSmuggler) (Object) serverAddress).e4mc$getSmuggledTicket();
        if (smuggledTicket != null) {
            return instance.resolve(serverAddress).map(addr -> ResolvedServerAddress.from(new SmugglersInetSocketAddress(addr.asInetSocketAddress(), smuggledTicket)));
        }
        return instance.resolve(serverAddress);
    }

    @Unique
    private static void e4all$smuggleTicket(ServerAddress serverAddress, String ticket) {
        ((TicketSmuggler) (Object) serverAddress).e4mc$setSmuggledTicket(ticket);
        VoiceBridge.setPendingDialtoneTicket(ticket);
    }
}
