package link.e4all.mixin;

import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.objectweb.asm.tree.ClassNode;
import java.util.List;
import java.util.Set;

public class E4allMixinPlugin implements IMixinConfigPlugin {
    private static final boolean HAS_SIGNATURES;
    private static final boolean HAS_COMMON_LISTENER_COOKIE;
    private static final boolean HAS_CHAT_SESSION_UPDATE_PACKET;
    private static final boolean HAS_CHAT_SENDER;
    private static final boolean HAS_MULTIPLAYER_OPTIONS_SCREEN;
    private static final boolean HAS_SHARE_TO_LAN_SCREEN;
    private static final boolean HAS_WORLD_OPTIONS_SCREEN;
    // 1.20.2+ custom payloads
    private static final boolean HAS_MODERN_PAYLOADS;
    // 1.21.2+ payload dispatch codec
    private static final boolean HAS_MODERN_PAYLOAD_CODEC_TARGETS;
    private static final boolean IS_FABRIC_RUNTIME = isFabricRuntime();
    private static final boolean HAS_LEGACY_GUI_MESSAGE_TAG;
    private static final boolean HAS_MODERN_GUI_MESSAGE_TAG;
    private static final int MC_GENERATION = detectMinecraftGeneration();
    static {
        boolean hasSignatures = false;
        try {
            ClassLoader cl = E4allMixinPlugin.class.getClassLoader();
            hasSignatures = cl.getResource("net/minecraft/network/chat/MessageSignature.class") != null
                         || cl.getResource("net/minecraft/network/message/MessageSignatureData.class") != null
                         || cl.getResource("net/minecraft/class_7469.class") != null;
        } catch (Throwable e) {
            // Pre-1.19
        }
        HAS_SIGNATURES = hasSignatures;

        boolean hasCookie = false;
        try {
            ClassLoader cl = E4allMixinPlugin.class.getClassLoader();
            hasCookie = cl.getResource("net/minecraft/server/network/CommonListenerCookie.class") != null
                     || cl.getResource("net/minecraft/class_8673.class") != null;
        } catch (Throwable ignored) {
        }
        HAS_COMMON_LISTENER_COOKIE = hasCookie;

        boolean hasChatSessionUpdate = false;
        boolean hasChatSender = false;
        try {
            ClassLoader cl = E4allMixinPlugin.class.getClassLoader();
            hasChatSessionUpdate =
                    cl.getResource("net/minecraft/network/protocol/game/ServerboundChatSessionUpdatePacket.class") != null
                    || cl.getResource("net/minecraft/class_7861.class") != null;
            hasChatSender = cl.getResource("net/minecraft/network/chat/ChatSender.class") != null;
        } catch (Throwable ignored) {
        }
        HAS_CHAT_SESSION_UPDATE_PACKET = hasChatSessionUpdate;
        HAS_CHAT_SENDER = hasChatSender;

        ClassLoader cl = E4allMixinPlugin.class.getClassLoader();
        HAS_MULTIPLAYER_OPTIONS_SCREEN =
                cl.getResource("net/minecraft/client/gui/screens/MultiplayerOptionsScreen.class") != null
             || cl.getResource("net/minecraft/client/gui/screens/options/MultiplayerOptionsScreen.class") != null;
        HAS_SHARE_TO_LAN_SCREEN =
                cl.getResource("net/minecraft/client/gui/screens/ShareToLanScreen.class") != null
             || cl.getResource("net/minecraft/class_527.class") != null;
        HAS_WORLD_OPTIONS_SCREEN =
                cl.getResource("net/minecraft/client/gui/screens/WorldOptionsScreen.class") != null;

        boolean hasModernPayloads = false;
        try {
            hasModernPayloads = cl.getResource("net/minecraft/network/protocol/common/ServerboundCustomPayloadPacket.class") != null
                             || cl.getResource("net/minecraft/class_8709.class") != null;
        } catch (Throwable ignored) {
        }
        HAS_MODERN_PAYLOADS = hasModernPayloads;

        boolean hasPayloadCodecTargets = false;
        try {
            hasPayloadCodecTargets =
                    cl.getResource("net/minecraft/network/protocol/common/custom/CustomPacketPayload$1.class") != null
                 && cl.getResource("net/minecraft/network/codec/IdDispatchCodec.class") != null;
        } catch (Throwable ignored) {
        }
        HAS_MODERN_PAYLOAD_CODEC_TARGETS = hasPayloadCodecTargets;

        HAS_LEGACY_GUI_MESSAGE_TAG = cl.getResource("net/minecraft/client/GuiMessageTag.class") != null;
        HAS_MODERN_GUI_MESSAGE_TAG =
                cl.getResource("net/minecraft/client/multiplayer/chat/GuiMessageTag.class") != null;
    }

    private static boolean isFabricRuntime() {
        try {
            Class.forName("net.fabricmc.loader.api.FabricLoader");
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static int detectMinecraftGeneration() {
        try {
            Class<?> loaderClass = Class.forName("net.fabricmc.loader.api.FabricLoader");
            Object loader = loaderClass.getMethod("getInstance").invoke(null);
            Object container = loaderClass.getMethod("getModContainer", String.class).invoke(loader, "minecraft");
            Object present = container.getClass().getMethod("orElse", Object.class).invoke(container, (Object) null);
            if (present == null) {
                return -1;
            }
            Object metadata = present.getClass().getMethod("getMetadata").invoke(present);
            Object version = metadata.getClass().getMethod("getVersion").invoke(metadata);
            String id = (String) version.getClass().getMethod("getId").invoke(version);
            String[] parts = id.split("[.+\\-]");
            if (parts.length < 2 || !"1".equals(parts[0])) {
                return 99;
            }
            return Integer.parseInt(parts[1]);
        } catch (Throwable t) {
            return -1;
        }
    }

    @Override
    public void onLoad(String mixinPackage) {}

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        if (mixinClassName.endsWith("PlayerListCookieMixin")) {
            return HAS_COMMON_LISTENER_COOKIE;
        }
        if (mixinClassName.endsWith("PlayerListLegacyMixin")) {
            return !HAS_COMMON_LISTENER_COOKIE;
        }

        if (mixinClassName.contains(".ncr.")) {
            if (mixinClassName.endsWith("MixinServerboundChatSessionUpdatePacket")) {
                if (MC_GENERATION < 0) {
                    return HAS_CHAT_SESSION_UPDATE_PACKET;
                }
                return HAS_CHAT_SESSION_UPDATE_PACKET && MC_GENERATION >= 21;
            }
            if (mixinClassName.endsWith("MixinPlayerListLegacy")
                    || mixinClassName.endsWith("MixinServerGamePacketListenerImpl")) {
                return HAS_SIGNATURES && HAS_CHAT_SENDER;
            }
            if (mixinClassName.endsWith("MixinPlayerList")) {
                return HAS_SIGNATURES && !HAS_CHAT_SENDER;
            }
            return HAS_SIGNATURES;
        }

        if (mixinClassName.endsWith("ChatComponentTaggedMixin")) {
            return HAS_SIGNATURES && !HAS_MODERN_GUI_MESSAGE_TAG
                    && (HAS_LEGACY_GUI_MESSAGE_TAG
                            || (IS_FABRIC_RUNTIME && MC_GENERATION > 0 && MC_GENERATION < 26));
        }
        if (mixinClassName.endsWith("ChatComponentModernTaggedMixin")) {
            return HAS_SIGNATURES && HAS_MODERN_GUI_MESSAGE_TAG;
        }

        if (mixinClassName.endsWith("MultiplayerOptionsScreenMixin")) {
            return HAS_MULTIPLAYER_OPTIONS_SCREEN;
        }
        if (mixinClassName.endsWith("ShareToLanScreenMixin")) {
            return HAS_SHARE_TO_LAN_SCREEN;
        }
        if (mixinClassName.endsWith("WorldOptionsScreenMixin")) {
            return HAS_WORLD_OPTIONS_SCREEN;
        }

        if (mixinClassName.endsWith("CustomPayloadDispatchCodecMixin")
                || mixinClassName.endsWith("IdDispatchCodecMixin")) {
            return HAS_MODERN_PAYLOAD_CODEC_TARGETS;
        }

        if (mixinClassName.endsWith("ClientboundCustomPayloadPacketMixin")
                || mixinClassName.endsWith("DiscardedPayloadMixin")
                || mixinClassName.endsWith("ServerboundCustomPayloadPacketMixin")
                || mixinClassName.endsWith("ServerCommonPacketListenerImplMixin")
                || mixinClassName.endsWith("ServerCommonPacketListenerImplAccessor")
                || mixinClassName.endsWith("ClientCommonPacketListenerImplMixin")) {
            return HAS_MODERN_PAYLOADS;
        }

        return true;
    }

    public static boolean hasModernPayloads() {
        return HAS_MODERN_PAYLOADS;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}
}
