package link.e4all;

import folk.sisby.kaleido.api.ReflectiveConfig;
import folk.sisby.kaleido.lib.quiltconfig.api.annotations.Comment;
import folk.sisby.kaleido.lib.quiltconfig.api.values.TrackedValue;

public class Config extends ReflectiveConfig {
    public static final Config INSTANCE = Config.createToml(Agnos.configDir(), "e4all", "e4all", Config.class);

    @Comment("Whether to use the broker to get the best relay based on location or use a hard-coded relay.")
    public final TrackedValue<Boolean> useBroker = this.value(true);
    public final TrackedValue<String> brokerUrl = this.value("https://broker.e4mc.link/getBestRelay");    
    public final TrackedValue<String> relayHost = this.value("test.e4mc.link");
    public final TrackedValue<Integer> relayPort = this.value(25575);

    @Comment("Allows use of certain dedicated server commands such as /ban and /whitelist")
    public final TrackedValue<Boolean> restoreDedicatedCommands = this.value(true);
    @Comment("Whether to use whitelists on LAN worlds")
    public final TrackedValue<Boolean> useWhiteList = this.value(false);

    @Comment("Whether to enable sharing LAN worlds with e4all")
    public final TrackedValue<Boolean> hostEnabled = this.value(true);
    @Comment("Keep the world ticking while e4all is hosting it. Vanilla pauses a singleplayer world on ESC and on window focus loss, and a paused world freezes every connected guest until they are dropped. Dedicated servers never pause.")
    public final TrackedValue<Boolean> preventPauseWhileHosting = this.value(true);
    @Comment("Whether to enable Dialtone peer-to-peer connections as the host")
    public final TrackedValue<Boolean> dialtoneHostEnabled = this.value(true);
    @Comment("Whether to enable Dialtone peer-to-peer connections as the player")
    public final TrackedValue<Boolean> dialtonePlayerEnabled = this.value(true);
    @Comment("The URL to get the list of Iroh relays to use")
    public final TrackedValue<String> dialtoneRelayMap = this.value("https://natives.e4mc.link/relaymap.json");
    @Comment("Whether to hide direct IP addresses from the relay")
    public final TrackedValue<Boolean> dialtoneSanitizeTicket = this.value(true);
    @Comment("Keepalive probe interval in seconds to keep the relay session alive")
    public final TrackedValue<Integer> keepaliveIntervalSeconds = this.value(15);
    @Comment("How long (in ms) a guest login may wait for a starting world to finish its first tick before being rejected. Heavy modpacks can stall a full server tick for several seconds; waiting avoids kicking everyone who joins in that window. Set to 0 to reject immediately instead of waiting.")
    public final TrackedValue<Integer> loginReadyTimeoutMs = this.value(15000);
    @Comment("How long (in ms) the connection to the relay may take before retrying.")
    public final TrackedValue<Integer> relayConnectTimeoutMs = this.value(15000);

    @Comment("Whether to enable offline mode (disables Microsoft authentication for ALL LAN connections, including both tunneled and direct). Toggle via the 'Online Mode' button on the Open to LAN screen.")
    public final TrackedValue<Boolean> offlineMode = this.value(false);
    @Comment("Whether the offline mode warning has already been shown to the user")
    public final TrackedValue<Boolean> offlineWarningShown = this.value(false);

    @Comment("Whether the welcome message has already been shown to the user")
    public final TrackedValue<Boolean> welcomeShown = this.value(false);

    @Comment("Whether to hide the domain in the chat message (click to copy still works)")
    public final TrackedValue<Boolean> hideDomainInChat = this.value(false);

    @Comment("Master switch for SVC P2P voice support. When disabled, voice will not be negotiated.")
    public final TrackedValue<Boolean> voiceP2PEnabled = this.value(true);
}
