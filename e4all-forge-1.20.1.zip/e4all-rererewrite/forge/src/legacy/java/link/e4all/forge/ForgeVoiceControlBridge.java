package link.e4all.forge;

import link.e4all.E4allClient;
import net.minecraft.server.level.ServerPlayer;

/**
 * Forge 1.18 - 1.20.1 variant. These versions have no ChannelBuilder / EventNetworkChannel
 * (that netcode arrived with Forge for 1.20.2+), so no Forge channel is registered.
 * Voice control payloads travel as plain custom-payload packets and are picked up by
 * LegacyPayloadBridge. Returning false makes VoiceControl fall back to PacketHelper.
 * Method names/signatures must match what VoiceControlPayload calls reflectively.
 */
public final class ForgeVoiceControlBridge {
    private ForgeVoiceControlBridge() {}

    public static synchronized void register() {
        E4allClient.LOGGER.info("e4all voice: legacy Forge runtime, using the pipeline payload bridge");
    }

    public static boolean sendServerbound(byte[] data) {
        return false;
    }

    public static boolean sendClientbound(ServerPlayer player, byte[] data) {
        return false;
    }
}
